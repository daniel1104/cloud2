package com.cloud.register.serviceregister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegisterApplicationTests {

    @Test
    void contextLoads() {
    }

}
