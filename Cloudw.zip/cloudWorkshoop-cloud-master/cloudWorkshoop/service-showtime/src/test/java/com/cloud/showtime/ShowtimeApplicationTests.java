package com.cloud.showtime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowtimeApplicationTests {

    @Test
    void contextLoads() {
    }

}
