package com.cloud.booking.client;

import com.cloud.booking.modules.Movie;
import com.example.multimodule.service.utils.Response;
import com.example.multimodule.service.utils.ResponseBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MovieFallBackHystrix implements MovieClient{

    private final ResponseBuilder builder;

    @Override
    public Response findByID(Long id) {
        return builder.success(new Movie());
    }

}
