package com.cloud.booking.modules;

import lombok.Data;

@Data
public class User {

    private Long id;
    private String name;
    private String lastName;
}
